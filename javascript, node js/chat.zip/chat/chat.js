var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);

// Port tracking
server.listen(3000);

// Tracking Url and displaying the desired HTML page
app.get('/', function(request, respons) {
    respons.sendFile(__dirname + '/page0.html'); 
});

app.post('/', function(request, respons) {
    respons.sendFile(__dirname + '/page1.html');       
});


app.get('/', function(request, respons) {
    respons.sendFile(__dirname + '/signout.html');       
});

app.use('/public', express.static('public'));
app.use('/image', express.static('image'));

// Array with all connections
connections = [];

// Function that work when connected to the page
// Considered as a new user
io.sockets.on('connection', function(socket) {
	console.log("Connected");
	// Adding a new connection to an array
	connections.push(socket);

	// Function that works when disconnected from the server
	socket.on('disconnect', function(data) {
		// Removing a user from array
		connections.splice(connections.indexOf(socket), 1);
		console.log("Disconected");
	});

	// Function receiving a message from a user
	socket.on('send mess', function(data) {
		// Inside the function, we pass the 'add mess' event,
		// which will be called by all users and they will add a new message
		io.sockets.emit('add mess', {mess: data.mess, name: data.name, className: data.className});
	});

});